﻿namespace MapperCaseStudygRPC.Models
{
    public class MedicineMapper
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int SupplierId { get; set; }
    }
}
