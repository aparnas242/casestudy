﻿namespace MapperCaseStudygRPC.Models
{
    public class SupplierMapper
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Country { get; set; }
    }
}
