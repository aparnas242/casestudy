using AutoMapper;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using MapperCaseStudy;
using MapperCaseStudygRPC.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Threading.Tasks;
using static MapperCaseStudy.MapperService;

namespace MapperCaseStudy.Services
{
    public class MapperService : MapperServiceBase
    {
        private readonly ILogger<MapperService> _logger;
        private readonly IMapper _mapper;
        private readonly string _connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=PharmaDB;Integrated Security=True;";

        public MapperService(ILogger<MapperService> logger, IMapper mapper)
        {
            _logger = logger;
            _mapper = mapper;
        }

        //public override async Task<PharmacyList> GetPharmacies(Empty request, ServerCallContext context)
        //{
        //    var pharmacies = new PharmacyList();

        //    using (SqlConnection conn = new SqlConnection(_connectionString))
        //    {
        //        await conn.OpenAsync();
        //        string query = "EXEC GetPharmacies";

        //        using (SqlCommand cmd = new SqlCommand(query, conn))
        //        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
        //        {
        //            while (await reader.ReadAsync())
        //            {
        //                pharmacies.Pharmacies.Add(new Pharmacy
        //                {
        //                    Id = reader.GetInt32(0),
        //                    Name = reader.GetString(1),
        //                    Location = reader.GetString(2)
        //                });
        //            }
        //        }
        //    }
        //    return pharmacies;
        //}
        public override async Task<CustomerList> GetCustomers(Empty request, ServerCallContext context)
        {
            var customerMappedList = new List<CustomerMapper>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string query = "EXEC GetCustomers";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        customerMappedList.Add(new CustomerMapper
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1)
                        });
                    }
                }
            }
            var customers = new CustomerList();
            customers.Customers.AddRange(_mapper.Map<IEnumerable<Customer>>(customerMappedList));
            return customers;
        }
        public override async Task<PharmacyDetailsList> GetPharmacyDetails(Empty request, ServerCallContext context)
        {
            var pharmacyDetailsMappedList = new List<PharmacyDetailsMapper>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {

                await conn.OpenAsync();
                string query = "EXEC GetPharmacyDetails";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        pharmacyDetailsMappedList.Add(new PharmacyDetailsMapper
                        {
                            PharmacyId = reader.GetInt32(0),
                            PharmacyName = reader.GetString(1),
                            PharmacyLocation = reader.GetString(2),
                            TotalMedicineBatches = reader.GetInt32(3),
                            TotalPrescriptionsIssued = reader.GetInt32(4),
                            SupplierNames = reader.GetString(5)
                        });
                    }
                }
            }
            var pharmacyDetailsList = new PharmacyDetailsList();
            pharmacyDetailsList.PharmacyDetails.AddRange(_mapper.Map<IEnumerable<PharmacyDetails>>(pharmacyDetailsMappedList));
            return pharmacyDetailsList;
        }

        public override async Task<MedicinePrescriptionInfo> GetMedicinePrescriptionInfo(MedicinePrescriptionRequest request, ServerCallContext context)
        {
            var medPrescriptionList = new MedPrescriptionMapper();

            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    using (var command = new SqlCommand("GetMedicinePrescriptionInfo", connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@PatientId", request.PatientId);

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {

                                medPrescriptionList.CustomerId = reader.GetInt32(0); // c.Id
                                medPrescriptionList.PatientName = reader.GetString(1); // c.Name
                                medPrescriptionList.PrescriptionId = reader.GetInt32(2); // p.Id
                                medPrescriptionList.PrescriptionDate = reader.GetDateTime(3); // p.DateIssued
                                medPrescriptionList.MedicineId = reader.GetInt32(4); // m.Id
                                medPrescriptionList.MedicineName = reader.GetString(5); // m.Name
                                medPrescriptionList.SupplierName = reader.GetString(6); // s.Name
                                medPrescriptionList.SupplierCountry = reader.GetString(7);// s.Country
                             
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                throw new RpcException(new Status(StatusCode.Internal, "An error occurred while fetching prescription data."));
            }

            // Convert to gRPC response format
            var response = new MedicinePrescriptionInfo();
            response=_mapper.Map<MedicinePrescriptionInfo>(medPrescriptionList);

            return response;
        }
    }
}


                //public override async Task<DoctorList> GetDoctors(Empty request, ServerCallContext context)
                //{
                //    var doctors = new DoctorList();

//    using (SqlConnection conn = new SqlConnection(_connectionString))
//    {
//        await conn.OpenAsync();
//        string query = "EXEC GetDoctors";

//        using (SqlCommand cmd = new SqlCommand(query, conn))
//        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
//        {
//            while (await reader.ReadAsync())
//            {
//                doctors.Doctors.Add(new Doctor
//                {
//                    Id = reader.GetInt32(0),
//                    Name = reader.GetString(1),
//                    Specialization = reader.GetString(2)
//                });
//            }
//        }
//    }
//    return doctors;
//}

//                //public override async Task<MedicineList> GetMedicines(Empty request, ServerCallContext context)
//                //{
//                //    var medicines = new MedicineList();

//                //    using (SqlConnection conn = new SqlConnection(_connectionString))
//                //    {
//                //        await conn.OpenAsync();
//                //        string query = "EXEC GetMedicines";

//                //        using (SqlCommand cmd = new SqlCommand(query, conn))
//                //        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
//                //        {
//                //            while (await reader.ReadAsync())
//                //            {
//                //                medicines.Medicines.Add(new Medicine
//                //                {
//                //                    Id = reader.GetInt32(0),
//                //                    Name = reader.GetString(1),
//                //                    SupplierId = reader.GetInt32(2)
//                //                });
//                //            }
//                //        }
//                //    }
//                //    return medicines;
//                //}

//                //public override async Task<SupplierList> GetSuppliers(Empty request, ServerCallContext context)
//                //{
//                //    var suppliers = new SupplierList();

//                //    using (SqlConnection conn = new SqlConnection(_connectionString))
//                //    {
//                //        await conn.OpenAsync();
//                //        string query = "EXEC GetSuppliers";

//                //        using (SqlCommand cmd = new SqlCommand(query, conn))
//                //        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
//                //        {
//                //            while (await reader.ReadAsync())
//                //            {
//                //                suppliers.Suppliers.Add(new Supplier
//                //                {
//                //                    Id = reader.GetInt32(0),
//                //                    Name = reader.GetString(1),
//                //                    Country = reader.GetString(2)
//                //                });
//                //            }
//                //        }
//                //    }
//                //    return suppliers;
//                //}

//                //public override async Task<BatchList> GetBatches(Empty request, ServerCallContext context)
//                //{
//                //    var batchList = new BatchList();

//                //    using (SqlConnection conn = new SqlConnection(_connectionString))
//                //    {
//                //        await conn.OpenAsync();
//                //        string query = "EXEC GetBatches"; // Ensure stored procedure returns all columns

//                //        using (SqlCommand cmd = new SqlCommand(query, conn))
//                //        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
//                //        {
//                //            while (await reader.ReadAsync())
//                //            {
//                //                batchList.Batches.Add(new Batch
//                //                {
//                //                    Id = reader.GetInt32(0),  
//                //                    MedicineId = reader.GetInt32(1), 
//                //                    BatchNumber = reader.GetString(2),
//                //                    ExpiryDate = Timestamp.FromDateTime(reader.GetDateTime(3).ToUniversalTime()),
//                //                    Quantity = reader.GetInt32(4),
//                //                    FormattedExpiryDate = reader.GetDateTime(3).ToString("yyyy-MM-dd")
//                //                });
//                //            }
//                //        }
//                //    }
//                //    return batchList;
//                //}

//            }
//}
