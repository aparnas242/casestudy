﻿//using Google.Protobuf.WellKnownTypes;
using Grpc.Net.Client;
using MapperCaseStudy;
using System;
using System.Threading.Tasks;

class Program   
{
    static async Task Main()
    {
        var channel = GrpcChannel.ForAddress(" https://localhost:7290");
        var client=new MapperService.MapperServiceClient(channel);

        var response = await client.GetPharmaciesAsync(new Empty());
        foreach (var pharmacy in response.Pharmacies)
        {
            Console.WriteLine($"ID: {pharmacy.Id}, Name: {pharmacy.Name}, Location: {pharmacy.Location}");
        }
    }
}
