using AutoMapper;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using MapperCaseStudy;
using MapperCaseStudygRPC.Models;
using Microsoft.Data.SqlClient;
using Mapster;
using System;
using System.Threading.Tasks;
using static MapperCaseStudy.MapperService;
using MapperCaseStudygRPC;

namespace MapperCaseStudy.Services
{
    public class MapperService : MapperServiceBase
    {
        private readonly ILogger<MapperService> _logger;
        private readonly IMapper _mapper;
        private readonly TypeAdapterConfig _mapsterConfig;
        private readonly IMyMapper _myMapper;

        private readonly string _connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=PharmaDB;Integrated Security=True;";

        public MapperService(ILogger<MapperService> logger, IMapper mapper, IMyMapper myMapper)
        {
            _logger = logger;
            _mapper = mapper;
            _mapsterConfig = new TypeAdapterConfig();
            _myMapper = myMapper;
        }

        
        public override async Task<CustomerList> GetCustomers(Empty request, ServerCallContext context)
        {
            List<CustomerMapper> customerMappedList = new List<CustomerMapper>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string query = "EXEC GetCustomers";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        customerMappedList.Add(new CustomerMapper
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1)
                        });
                    }
                }
            }
            //var customers = new CustomerList();
            //customers.Customers.AddRange(_mapper.Map<IEnumerable<Customer>>(customerMappedList));
            //customers.Customers.AddRange(customerMappedList.Adapt<IEnumerable<Customer>>(_mapsterConfig));
            //customers.Customers.AddRange(_myMapper.MapCustomers(customerMappedList));
            // Perform mappings using AutoMapper, Mapster, and Mapperly
            var autoMappedCustomers = _mapper.Map<IEnumerable<Customer>>(customerMappedList);
            var mapsterMappedCustomers = customerMappedList.Adapt<IEnumerable<Customer>>(_mapsterConfig);
            var mapperlyMappedCustomers = _myMapper.MapCustomers(customerMappedList);

            // Log the results for comparison
            _logger.LogInformation("AutoMapped: {Count} | MapsterMapped: {Count} | MapperlyMapped: {Count}",
                autoMappedCustomers.Count(), mapsterMappedCustomers.Count(), mapperlyMappedCustomers.Count());

            //_logger.LogInformation("AutoMapped Customers: {Names}", string.Join(", ", autoMappedCustomers.Select(c => c.Name)));
            //_logger.LogInformation("MapsterMapped Customers: {Names}", string.Join(", ", mapsterMappedCustomers.Select(c => c.Name)));
            //_logger.LogInformation("MapperlyMapped Customers: {Names}", string.Join(", ", mapperlyMappedCustomers.Select(c => c.Name)));

            // Return only AutoMapper's result
            var customers = new CustomerList();
            customers.Customers.AddRange(autoMappedCustomers);
            return customers;
        }
        public override async Task<PharmacyDetailsList> GetPharmacyDetails(Empty request, ServerCallContext context)
        {
            var pharmacyDetailsMappedList = new List<PharmacyDetailsMapper>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {

                await conn.OpenAsync();
                string query = "EXEC GetPharmacyDetails";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        pharmacyDetailsMappedList.Add(new PharmacyDetailsMapper
                        {
                            PharmacyId = reader.GetInt32(0),
                            PharmacyName = reader.GetString(1),
                            PharmacyLocation = reader.GetString(2),
                            TotalMedicineBatches = reader.GetInt32(3),
                            TotalPrescriptionsIssued = reader.GetInt32(4),
                            SupplierNames = reader.GetString(5)
                        });
                    }
                }
            }
            // var pharmacyDetailsList = new PharmacyDetailsList();
            //pharmacyDetailsList.PharmacyDetails.AddRange(_mapper.Map<IEnumerable<PharmacyDetails>>(pharmacyDetailsMappedList));
            //pharmacyDetailsList.PharmacyDetails.AddRange(pharmacyDetailsMappedList.Adapt<IEnumerable<PharmacyDetails>>(_mapsterConfig));
            //pharmacyDetailsList.PharmacyDetails.AddRange(_myMapper.MapPharmacyDetails(pharmacyDetailsMappedList));
            // return pharmacyDetailsList;
            var autoMappedPharmacyDetails = _mapper.Map<IEnumerable<PharmacyDetails>>(pharmacyDetailsMappedList);
            var mapsterMappedPharmacyDetails = pharmacyDetailsMappedList.Adapt<IEnumerable<PharmacyDetails>>(_mapsterConfig);
            var mapperlyMappedPharmacyDetails = _myMapper.MapPharmacyDetails(pharmacyDetailsMappedList);

            // Log the results for comparison
            _logger.LogInformation("AutoMapped: {Count} | MapsterMapped: {Count} | MapperlyMapped: {Count}",
                autoMappedPharmacyDetails.Count(), mapsterMappedPharmacyDetails.Count(), mapperlyMappedPharmacyDetails.Count());

            //_logger.LogInformation("AutoMapped Pharmacy Details: {Names}", string.Join(", ", autoMappedPharmacyDetails.Select(p => p.PharmacyName)));
            //_logger.LogInformation("MapsterMapped Pharmacy Details: {Names}", string.Join(", ", mapsterMappedPharmacyDetails.Select(p => p.PharmacyName)));
            //_logger.LogInformation("MapperlyMapped Pharmacy Details: {Names}", string.Join(", ", mapperlyMappedPharmacyDetails.Select(p => p.PharmacyName)));

            // Return only AutoMapper's result
            var pharmacyDetailsList = new PharmacyDetailsList();
            pharmacyDetailsList.PharmacyDetails.AddRange(autoMappedPharmacyDetails);

            return pharmacyDetailsList;
        }

        public override async Task<MedicinePrescriptionInfo> GetMedicinePrescriptionInfo(MedicinePrescriptionRequest request, ServerCallContext context)
        {
            var medPrescriptionList = new MedPrescriptionMapper();

            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    using (var command = new SqlCommand("GetMedicinePrescriptionInfo", connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@PatientId", request.PatientId);

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {

                                medPrescriptionList.CustomerId = reader.GetInt32(0); // c.Id
                                medPrescriptionList.PatientName = reader.GetString(1); // c.Name
                                medPrescriptionList.PrescriptionId = reader.GetInt32(2); // p.Id
                                medPrescriptionList.PrescriptionDate = reader.GetDateTime(3); // p.DateIssued
                                medPrescriptionList.MedicineId = reader.GetInt32(4); // m.Id
                                medPrescriptionList.MedicineName = reader.GetString(5); // m.Name
                                medPrescriptionList.SupplierName = reader.GetString(6); // s.Name
                                medPrescriptionList.SupplierCountry = reader.GetString(7);// s.Country
                             
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                throw new RpcException(new Status(StatusCode.Internal, "An error occurred while fetching prescription data."));
            }

            // Convert to gRPC response format
            //var response = new MedicinePrescriptionInfo();
            //response=_mapper.Map<MedicinePrescriptionInfo>(medPrescriptionList);
            //response = medPrescriptionList.Adapt<MedicinePrescriptionInfo>(_mapsterConfig);
            //response = _myMapper.MapMedicinePrescription(medPrescriptionList);
            //return response;
            var autoMappedResponse = _mapper.Map<MedicinePrescriptionInfo>(medPrescriptionList);
            var mapsterMappedResponse = medPrescriptionList.Adapt<MedicinePrescriptionInfo>(_mapsterConfig);
            var mapperlyMappedResponse = _myMapper.MapMedicinePrescription(medPrescriptionList);

            // Log the mappings for comparison
            _logger.LogInformation("AutoMapped: {Name} | MapsterMapped: {Name} | MapperlyMapped: {Name}",
                autoMappedResponse.PatientName, mapsterMappedResponse.PatientName, mapperlyMappedResponse.PatientName);

            //_logger.LogInformation("AutoMapped: {MedicineName}, {SupplierName}", autoMappedResponse.MedicineName, autoMappedResponse.SupplierName);
            //_logger.LogInformation("MapsterMapped: {MedicineName}, {SupplierName}", mapsterMappedResponse.MedicineName, mapsterMappedResponse.SupplierName);
            //_logger.LogInformation("MapperlyMapped: {MedicineName}, {SupplierName}", mapperlyMappedResponse.MedicineName, mapperlyMappedResponse.SupplierName);

            // Return only AutoMapper's mapped result
            return autoMappedResponse;
        }
    }
}


//public override async Task<DoctorList> GetDoctors(Empty request, ServerCallContext context)
//{
//    var doctors = new DoctorList();

//    using (SqlConnection conn = new SqlConnection(_connectionString))
//    {
//        await conn.OpenAsync();
//        string query = "EXEC GetDoctors";

//        using (SqlCommand cmd = new SqlCommand(query, conn))
//        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
//        {
//            while (await reader.ReadAsync())
//            {
//                doctors.Doctors.Add(new Doctor
//                {
//                    Id = reader.GetInt32(0),
//                    Name = reader.GetString(1),
//                    Specialization = reader.GetString(2)
//                });
//            }
//        }
//    }
//    return doctors;
//}

//                //public override async Task<MedicineList> GetMedicines(Empty request, ServerCallContext context)
//                //{
//                //    var medicines = new MedicineList();

//                //    using (SqlConnection conn = new SqlConnection(_connectionString))
//                //    {
//                //        await conn.OpenAsync();
//                //        string query = "EXEC GetMedicines";

//                //        using (SqlCommand cmd = new SqlCommand(query, conn))
//                //        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
//                //        {
//                //            while (await reader.ReadAsync())
//                //            {
//                //                medicines.Medicines.Add(new Medicine
//                //                {
//                //                    Id = reader.GetInt32(0),
//                //                    Name = reader.GetString(1),
//                //                    SupplierId = reader.GetInt32(2)
//                //                });
//                //            }
//                //        }
//                //    }
//                //    return medicines;
//                //}

//                //public override async Task<SupplierList> GetSuppliers(Empty request, ServerCallContext context)
//                //{
//                //    var suppliers = new SupplierList();

//                //    using (SqlConnection conn = new SqlConnection(_connectionString))
//                //    {
//                //        await conn.OpenAsync();
//                //        string query = "EXEC GetSuppliers";

//                //        using (SqlCommand cmd = new SqlCommand(query, conn))
//                //        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
//                //        {
//                //            while (await reader.ReadAsync())
//                //            {
//                //                suppliers.Suppliers.Add(new Supplier
//                //                {
//                //                    Id = reader.GetInt32(0),
//                //                    Name = reader.GetString(1),
//                //                    Country = reader.GetString(2)
//                //                });
//                //            }
//                //        }
//                //    }
//                //    return suppliers;
//                //}

//                //public override async Task<BatchList> GetBatches(Empty request, ServerCallContext context)
//                //{
//                //    var batchList = new BatchList();

//                //    using (SqlConnection conn = new SqlConnection(_connectionString))
//                //    {
//                //        await conn.OpenAsync();
//                //        string query = "EXEC GetBatches"; // Ensure stored procedure returns all columns

//                //        using (SqlCommand cmd = new SqlCommand(query, conn))
//                //        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
//                //        {
//                //            while (await reader.ReadAsync())
//                //            {
//                //                batchList.Batches.Add(new Batch
//                //                {
//                //                    Id = reader.GetInt32(0),  
//                //                    MedicineId = reader.GetInt32(1), 
//                //                    BatchNumber = reader.GetString(2),
//                //                    ExpiryDate = Timestamp.FromDateTime(reader.GetDateTime(3).ToUniversalTime()),
//                //                    Quantity = reader.GetInt32(4),
//                //                    FormattedExpiryDate = reader.GetDateTime(3).ToString("yyyy-MM-dd")
//                //                });
//                //            }
//                //        }
//                //    }
//                //    return batchList;
//                //}

//            }
//}
//public override async Task<PharmacyList> GetPharmacies(Empty request, ServerCallContext context)
//{
//    var pharmacies = new PharmacyList();

//    using (SqlConnection conn = new SqlConnection(_connectionString))
//    {
//        await conn.OpenAsync();
//        string query = "EXEC GetPharmacies";

//        using (SqlCommand cmd = new SqlCommand(query, conn))
//        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
//        {
//            while (await reader.ReadAsync())
//            {
//                pharmacies.Pharmacies.Add(new Pharmacy
//                {
//                    Id = reader.GetInt32(0),
//                    Name = reader.GetString(1),
//                    Location = reader.GetString(2)
//                });
//            }
//        }
//    }
//    return pharmacies;
//}
