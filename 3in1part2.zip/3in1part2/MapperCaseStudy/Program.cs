using MapperCaseStudy.Services;
using Microsoft.Extensions.DependencyInjection;
using AutoMapper;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Hosting;
using MapperCaseStudygRPC;
using MapperCaseStudygRPC.Models;
using MapperCaseStudygRPC.Models.Dto;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddGrpc();

//Automapper


builder.Services.AddAutoMapper(typeof(MappingProfile));
MapsterMappingConfig.ConfigureMappings();
builder.Services.AddSingleton<MappingProfile>();
builder.Services.AddSingleton<IMyMapper, MyMapper>();

//var config = new MapperConfiguration(cfg => cfg.AddProfile<MappingProfile>());
//var mapper = config.CreateMapper();


//var cust = new CustomerMapper()
//{
//    Id = 1,
//    Name = "Daniel"
//};

//var mappedCustomer = mapper.Map<CustomerDto>(cust);
//Console.WriteLine($"ID:{mappedCustomer.Id},name:{mappedCustomer.Name}");

//builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());


var services = new ServiceCollection();


var app = builder.Build();

// Configure the HTTP request pipeline.
app.MapGrpcService<MapperService>();
app.MapGet("/", () => "gRPC Pharmacy Service is running.");
app.Run();
