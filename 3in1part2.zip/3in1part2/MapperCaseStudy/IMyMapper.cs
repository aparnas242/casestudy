﻿using MapperCaseStudy;
using MapperCaseStudygRPC.Models;
using Riok.Mapperly.Abstractions;

namespace MapperCaseStudygRPC
{
    public interface IMyMapper
    {
        IEnumerable<Customer> MapCustomers(IEnumerable<CustomerMapper> customers);
        IEnumerable<PharmacyDetails> MapPharmacyDetails(IEnumerable<PharmacyDetailsMapper> pharmacyDetails);
        //PharmacyDetailsList MapPharmacyDetails(IEnumerable<PharmacyDetailsMapper> pharmacyDetails);
        MedicinePrescriptionInfo MapMedicinePrescription(MedPrescriptionMapper prescription); 
    }
}
