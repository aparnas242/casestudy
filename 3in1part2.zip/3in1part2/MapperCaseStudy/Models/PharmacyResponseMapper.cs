﻿namespace MapperCaseStudygRPC.Models
{
    public class PharmacyResponseMapper
    {
        public List<PharmacyDetailsMapper> PharmacyDetails { get; set; }
    }
}
