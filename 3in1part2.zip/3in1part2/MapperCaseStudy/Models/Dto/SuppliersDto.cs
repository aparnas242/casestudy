﻿namespace MapperCaseStudygRPC.Models
{
    public class SuppliersDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Country { get; set; }
    }
}
