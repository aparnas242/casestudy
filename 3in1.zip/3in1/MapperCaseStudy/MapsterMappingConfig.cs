﻿using MapperCaseStudy;
using MapperCaseStudygRPC.Models;
using Mapster;

namespace MapperCaseStudygRPC
{
    public class MapsterMappingConfig
    {
        public static void ConfigureMappings()
        {
            TypeAdapterConfig<CustomerMapper, Customer>.NewConfig();
            TypeAdapterConfig<PharmacyDetailsMapper, PharmacyDetails>.NewConfig();
            TypeAdapterConfig<MedPrescriptionMapper, MedicinePrescriptionInfo>.NewConfig()
                .Map(dest => dest.CustomerId, src => src.CustomerId)
                .Map(dest => dest.PatientName, src => src.PatientName)
                .Map(dest => dest.PrescriptionId, src => src.PrescriptionId)
                .Map(dest => dest.PrescriptionDate, src => Google.Protobuf.WellKnownTypes.Timestamp.FromDateTime(src.PrescriptionDate.ToUniversalTime()))
                .Map(dest => dest.MedicineId, src => src.MedicineId)
                .Map(dest => dest.MedicineName, src => src.MedicineName)
                .Map(dest => dest.SupplierName, src => src.SupplierName)
                .Map(dest => dest.SupplierCountry, src => src.SupplierCountry);
        }
    }
}
