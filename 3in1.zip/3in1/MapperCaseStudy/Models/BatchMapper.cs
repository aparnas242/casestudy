﻿namespace MapperCaseStudygRPC.Models
{
    public class BatchMapper
    {
        public int Id { get; set; }
        public int MedicineId { get; set; }
        public string BatchNumber { get; set; }
        public DateOnly ExpiryDate { get; set; }
        public int Quantity { get; set; }
    }
}
