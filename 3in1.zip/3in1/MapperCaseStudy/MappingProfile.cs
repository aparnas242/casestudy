﻿using AutoMapper;
using Google.Protobuf.WellKnownTypes;
using MapperCaseStudy;
using MapperCaseStudygRPC.Models;
using MapperCaseStudygRPC.Models.Dto;

namespace MapperCaseStudygRPC
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<CustomerMapper, Customer>();
            CreateMap<PharmacyDetailsMapper, PharmacyDetails>();
            CreateMap<MedPrescriptionMapper, MedicinePrescriptionInfo>()
                .ForMember(dest => dest.CustomerId, opt => opt.MapFrom(src => src.CustomerId))
                .ForMember(dest => dest.PatientName, opt => opt.MapFrom(src => src.PatientName))
                .ForMember(dest => dest.PrescriptionId, opt => opt.MapFrom(src => src.PrescriptionId))
                .ForMember(dest => dest.PrescriptionDate, opt => opt.MapFrom(src => Timestamp.FromDateTime(src.PrescriptionDate.ToUniversalTime())))
                .ForMember(dest => dest.MedicineId, opt => opt.MapFrom(src => src.MedicineId))
                .ForMember(dest => dest.MedicineName, opt => opt.MapFrom(src => src.MedicineName))
                .ForMember(dest => dest.SupplierName, opt => opt.MapFrom(src => src.SupplierName))
                .ForMember(dest => dest.SupplierCountry, opt => opt.MapFrom(src => src.SupplierCountry));
        }
    }
}

// CreateMap<BatchMapper, Batch>();
// CreateMap<DoctorMapper, Doctor>();
// CreateMap<MedicineMapper, Medicine>();

// CreateMap<PharmacyMapper, Pharmacy>();
// CreateMap<SupplierMapper, Supplier>();