﻿using AutoMapper;
using Grpc.Net.Client;
using MapperCaseStudy;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        var channel = GrpcChannel.ForAddress("https://localhost:7290");
        var client = new MapperService.MapperServiceClient(channel);

        await GetCustomers(client);
        await GetPharmacyDetails(client);
        await GetMedicinePrescriptionInfo(client, 3);
        await GetProductionBatches(client);
    }


    static async Task GetMedicinePrescriptionInfo(MapperService.MapperServiceClient client, int patientId)
    {
        var request = new MedicinePrescriptionRequest { PatientId = patientId };
        var response = await client.GetMedicinePrescriptionInfoAsync(request);

        Console.WriteLine($"\nMedicine Prescription Info for Patient ID: {patientId}");
        Console.WriteLine(new string('-', 50));


        Console.WriteLine($"Customer ID: {response.CustomerId}");
        Console.WriteLine($"Patient Name: {response.PatientName}");
        Console.WriteLine($"Prescription ID: {response.PrescriptionId}");
        Console.WriteLine($"Prescription Date: {response.PrescriptionDate}");
        Console.WriteLine($"Medicine ID: {response.MedicineId}");
        Console.WriteLine($"Medicine Name: {response.MedicineName}");
        Console.WriteLine($"Supplier Name: {response.SupplierName}");
        Console.WriteLine($"Supplier Country: {response.SupplierCountry}");
        Console.WriteLine(new string('-', 50));

    }


    static async Task GetCustomers(MapperService.MapperServiceClient client)
    {
        var response = await client.GetCustomersAsync(new Empty());
        Console.WriteLine("\nCustomers:");
        foreach (var customer in response.Customers)
        {
            Console.WriteLine($"ID: {customer.Id}, Name: {customer.Name}");
        }
    }

    static async Task GetPharmacyDetails(MapperService.MapperServiceClient client)
    {
        var response = await client.GetPharmacyDetailsAsync(new Empty());
        Console.WriteLine("\nPharmacy Details:");
        foreach (var details in response.PharmacyDetails)
        {
            Console.WriteLine($"Pharmacy ID: {details.PharmacyId}, Name: {details.PharmacyName}, Location: {details.PharmacyLocation}, " +
                              $"Total Medicine Batches: {details.TotalMedicineBatches}, Prescriptions Issued: {details.TotalPrescriptionsIssued}, " +
                              $"Suppliers: {details.SupplierNames}");
        }
    }

    static async Task GetProductionBatches(MapperService.MapperServiceClient client)
    {
        // Making the gRPC call to GetProductionBatches
        var response = await client.GetProductionBatchesAsync(new Empty());

        // Displaying the fetched Production Batches
        Console.WriteLine("\nProduction Batches:");

        foreach (var batch in response.ProductionBatches)
        {
            Console.WriteLine($"Batch ID: {batch.Id}, Batch Number: {batch.BatchNumber}, Expiry Date: {batch.ExpiryDate}, Quantity: {batch.Quantity}");

            foreach (var product in batch.Products)
            {
                Console.WriteLine($"   - Product ID: {product.Id}, Name: {product.Name}");
                Console.WriteLine($"     Vendor: {product.Vendor.Name} ({product.Vendor.Country})");
            }
        }

    }
}

