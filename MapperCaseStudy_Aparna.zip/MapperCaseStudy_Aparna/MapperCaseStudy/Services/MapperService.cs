﻿using AutoMapper;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using MapperCaseStudy;
using MapperCaseStudygRPC.Models;
using Microsoft.Data.SqlClient;
using Mapster;
using System;
using System.Threading.Tasks;
using static MapperCaseStudy.MapperService;
using MapperCaseStudygRPC;
using System.Diagnostics;

namespace MapperCaseStudy.Services
{
    public class MapperService : MapperServiceBase
    {
        private readonly ILogger<MapperService> _logger;
        private readonly IMapper _mapper;
        private readonly TypeAdapterConfig _mapsterConfig;
        private readonly IMyMapper _myMapper;
        //private readonly string _connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=PharmaDB;Integrated Security=True;";

        //private readonly string _connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Pharma_DB;Integrated Security=True;";
        private readonly string _connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=PharmaDB_1;Integrated Security=True;";


        public MapperService(ILogger<MapperService> logger, IMapper mapper, IMyMapper myMapper)
        {
            _logger = logger;
            _mapper = mapper;
            _mapsterConfig = new TypeAdapterConfig();
            _myMapper = myMapper;
        }

        public override async Task<Customer> GetCustomerById(CustomerRequest request, ServerCallContext context)
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();

            CustomerMapper customerMapper = null;

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string query = "EXEC GetCustomerById @CustomerId";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@CustomerId", request.Id);
                    using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            customerMapper = new CustomerMapper
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1)
                            };
                        }
                    }
                }
            }

            if (customerMapper == null)
            {
                throw new RpcException(new Status(StatusCode.NotFound, "Customer not found"));
            }

            long beforeMemoryAutoMapper = GC.GetTotalMemory(true);
            Stopwatch stopwatchAutoMapper = new Stopwatch();
            stopwatchAutoMapper.Start();

            var autoMappedCustomer = _mapper.Map<Customer>(customerMapper);

            long afterMemoryAutoMapper = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetCustomerById AutoMapper: {(afterMemoryAutoMapper - beforeMemoryAutoMapper)} Bytes");

            stopwatchAutoMapper.Stop();
            Console.WriteLine("GetCustomerById AutoMapper Execution Time: " + stopwatchAutoMapper.ElapsedMilliseconds + " ms");

            long beforeMemoryMapster = GC.GetTotalMemory(true);
            Stopwatch stopwatchMapster = new Stopwatch();
            stopwatchMapster.Start();

            var mapsterMappedCustomer = customerMapper.Adapt<Customer>(_mapsterConfig);

            long afterMemoryMapster = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetCustomerById Mapster: {(afterMemoryMapster - beforeMemoryMapster)} Bytes");

            stopwatchMapster.Stop();
            Console.WriteLine("GetCustomerById Mapster Execution Time: " + stopwatchMapster.ElapsedMilliseconds + " ms");

            long beforeMemoryMapperly = GC.GetTotalMemory(true);
            Stopwatch stopwatchMapperly = new Stopwatch();
            stopwatchMapperly.Start();

            var mapperlyMappedCustomer = _myMapper.MapCustomer(customerMapper);

            long afterMemoryMapperly = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetCustomerById Mapperly: {(afterMemoryMapperly - beforeMemoryMapperly)} Bytes");

            stopwatchMapperly.Stop();
            Console.WriteLine("GetCustomerById Mapperly Execution Time: " + stopwatchMapperly.ElapsedMilliseconds + " ms");


            return autoMappedCustomer;
        }
        public override async Task<MedicinePrescriptionInfo> GetMedicinePrescriptionInfo(MedicinePrescriptionRequest request, ServerCallContext context)
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            var medPrescriptionList = new MedPrescriptionMapper();

            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    using (var command = new SqlCommand("GetMedicinePrescriptionInfo", connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@PatientId", request.PatientId);

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {

                                medPrescriptionList.CustomerId = reader.GetInt32(0);
                                medPrescriptionList.PatientName = reader.GetString(1);
                                medPrescriptionList.PrescriptionId = reader.GetInt32(2);
                                medPrescriptionList.PrescriptionDate = reader.GetDateTime(3);
                                medPrescriptionList.MedicineId = reader.GetInt32(4);
                                medPrescriptionList.MedicineName = reader.GetString(5);
                                medPrescriptionList.SupplierName = reader.GetString(6);
                                medPrescriptionList.SupplierCountry = reader.GetString(7);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                throw new RpcException(new Status(StatusCode.Internal, "An error occurred while fetching prescription data."));
            }

            long beforeMemoryAutoMapper = GC.GetTotalMemory(true);

            Stopwatch stopwatchAutoMapper = new Stopwatch();
            stopwatchAutoMapper.Start();

            var autoMappedResponse = _mapper.Map<MedicinePrescriptionInfo>(medPrescriptionList);

            long afterMemoryAutoMapper = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetMedicinePrescriptionInfo AutoMapper: {(afterMemoryAutoMapper - beforeMemoryAutoMapper)} Bytes");

            stopwatchAutoMapper.Stop();
            Console.WriteLine("GetMedicinePrescriptionInfo AutoMapper Execution Time: " + stopwatchAutoMapper.ElapsedMilliseconds + " ms");


            long beforeMemoryMapster = GC.GetTotalMemory(true);

            Stopwatch stopwatchMapster = new Stopwatch();
            stopwatchMapster.Start();

            var mapsterMappedResponse = medPrescriptionList.Adapt<MedicinePrescriptionInfo>(_mapsterConfig);

            long afterMemoryMapster = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetMedicinePrescriptionInfo Mapster: {(afterMemoryMapster - beforeMemoryMapster)} Bytes");

            stopwatchMapster.Stop();
            Console.WriteLine("GetMedicinePrescriptionInfo Mapster Execution Time: " + stopwatchMapster.ElapsedMilliseconds + " ms");

            long beforeMemoryMapperly = GC.GetTotalMemory(true);

            Stopwatch stopwatchMapperly = new Stopwatch();
            stopwatchMapperly.Start();

            var mapperlyMappedResponse = _myMapper.MapMedicinePrescription(medPrescriptionList);

            long afterMemoryMapperly = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetMedicinePrescriptionInfo Mapperly: {(afterMemoryMapperly - beforeMemoryMapperly)} Bytes");

            stopwatchMapperly.Stop();
            Console.WriteLine("GetMedicinePrescriptionInfo Mapperly Execution Time: " + stopwatchMapperly.ElapsedMilliseconds + " ms");

            _logger.LogInformation("AutoMapped: {Name} | MapsterMapped: {Name} | MapperlyMapped: {Name}",
                autoMappedResponse.PatientName, mapsterMappedResponse.PatientName, mapperlyMappedResponse.PatientName);

            return autoMappedResponse;
        }

        public override async Task<PharmacyDetailsList> GetPharmacyDetails(Empty request, ServerCallContext context)
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            var pharmacyDetailsMappedList = new List<PharmacyDetailsMapper>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {

                await conn.OpenAsync();
                string query = "EXEC GetPharmacyDetails";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    cmd.CommandTimeout = 120;
                    while (await reader.ReadAsync())
                    {
                        pharmacyDetailsMappedList.Add(new PharmacyDetailsMapper
                        {
                            PharmacyId = reader.GetInt32(0),
                            PharmacyName = reader.GetString(1),
                            PharmacyLocation = reader.GetString(2),
                            TotalMedicineBatches = reader.GetInt32(3),
                            TotalPrescriptionsIssued = reader.GetInt32(4),
                            SupplierNames = reader.GetString(5)
                        });
                    }
                }
            }

            long beforeMemoryAutoMapper = GC.GetTotalMemory(true);

            Stopwatch stopwatchAutoMapper = new Stopwatch();
            stopwatchAutoMapper.Start();

            var autoMappedPharmacyDetails = _mapper.Map<IEnumerable<PharmacyDetails>>(pharmacyDetailsMappedList);

            long afterMemoryAutoMapper = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetPharmacyDetails AutoMapper: {(afterMemoryAutoMapper - beforeMemoryAutoMapper)} Bytes");

            stopwatchAutoMapper.Stop();
            Console.WriteLine("GetPharmacyDetails AutoMapper Execution Time: " + stopwatchAutoMapper.ElapsedMilliseconds + " ms");

            long beforeMemoryMapster = GC.GetTotalMemory(true);

            Stopwatch stopwatchMapster = new Stopwatch();
            stopwatchMapster.Start();

            var mapsterMappedPharmacyDetails = pharmacyDetailsMappedList.Adapt<IEnumerable<PharmacyDetails>>(_mapsterConfig);

            long afterMemoryMapster = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetPharmacyDetails Mapster: {(afterMemoryMapster - beforeMemoryMapster)} Bytes");

            stopwatchMapster.Stop();
            Console.WriteLine("GetPharmacyDetails Mapster Execution Time: " + stopwatchMapster.ElapsedMilliseconds + " ms");

            long beforeMemoryMapperly = GC.GetTotalMemory(true);

            Stopwatch stopwatchMapperly = new Stopwatch();
            stopwatchMapperly.Start();

            var mapperlyMappedPharmacyDetails = _myMapper.MapPharmacyDetails(pharmacyDetailsMappedList);

            long afterMemoryMapperly = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetPharmacyDetails Mapperly: {(afterMemoryMapperly - beforeMemoryMapperly)} Bytes");

            stopwatchMapperly.Stop();
            Console.WriteLine("GetPharmacyDetails Mapperly Execution Time: " + stopwatchMapperly.ElapsedMilliseconds + " ms");

            _logger.LogInformation("AutoMapped: {Count} | MapsterMapped: {Count} | MapperlyMapped: {Count}",
                autoMappedPharmacyDetails.Count(), mapsterMappedPharmacyDetails.Count(), mapperlyMappedPharmacyDetails.Count());

            var pharmacyDetailsList = new PharmacyDetailsList();
            pharmacyDetailsList.PharmacyDetails.AddRange(autoMappedPharmacyDetails);

            return pharmacyDetailsList;
        }

        public override async Task<ProductionBatchList> GetProductionBatches(Empty request, ServerCallContext context)
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            var batchProductVendorMappedList = new List<BatchProductVendorMapper>();

            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                string query = "EXEC GetProductionBatchesWithProductsAndVendors";

                using (var cmd = new SqlCommand(query, connection))
                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        batchProductVendorMappedList.Add(new BatchProductVendorMapper
                        {
                            BatchId = reader.GetInt32(0),
                            BatchNumber = reader.GetString(1),
                            ExpiryDate = reader.GetDateTime(2),
                            Quantity = reader.GetInt32(3),
                            ProductId = reader.GetInt32(4),
                            ProductName = reader.GetString(5),
                            VendorId = reader.GetInt32(6),
                            VendorName = reader.GetString(7),
                            VendorCountry = reader.GetString(8)
                        });
                    }
                }
            }

            //Memory Allocation variable declaring
            long beforeMemoryAutoMapper = GC.GetTotalMemory(true);
            //code for starting a stop watch
            Stopwatch stopwatchAutoMapper = new Stopwatch();
            stopwatchAutoMapper.Start();

            // AutoMapper mapping
            var autoMappedProductionBatches = _mapper.Map<IEnumerable<ProductionBatch>>(batchProductVendorMappedList);

            //memory ending
            long afterMemoryAutoMapper = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetProductionBatches AutoMapper: {(afterMemoryAutoMapper - beforeMemoryAutoMapper)} Bytes");

            //code for stopping stopwatch and printing
            stopwatchAutoMapper.Stop();
            Console.WriteLine("GetProductionBatches AutoMapper Execution Time: " + stopwatchAutoMapper.ElapsedMilliseconds + " ms");


            //Memory Allocation variable declaring
            long beforeMemoryMapster = GC.GetTotalMemory(true);
            //code for starting a stop watch
            Stopwatch stopwatchMapster = new Stopwatch();
            stopwatchMapster.Start();

            // Mapster mapping
            var mapsterMappedProductionBatches = batchProductVendorMappedList.Adapt<IEnumerable<ProductionBatch>>();

            //memory ending
            long afterMemoryMapster = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetProductionBatches Mapster: {(afterMemoryMapster - beforeMemoryMapster)} Bytes");

            //code for stopping stopwatch and printing
            stopwatchMapster.Stop();
            Console.WriteLine("GetProductionBatches Mapster Execution Time: " + stopwatchMapster.ElapsedMilliseconds + " ms");



            //Memory Allocation variable declaring
            long beforeMemoryMapperly = GC.GetTotalMemory(true);
            //code for starting a stop watch
            Stopwatch stopwatchMapperly = new Stopwatch();
            stopwatchMapperly.Start();

            // Mapperly mapping
            var mapperlyMappedProductionBatches = _myMapper.MapBatchProductVendors(batchProductVendorMappedList);

            //memory ending
            long afterMemoryMapperly = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetProductionBatches Mapperly: {(afterMemoryMapperly - beforeMemoryMapperly)} Bytes");

            //code for stopping stopwatch and printing
            stopwatchMapperly.Stop();
            Console.WriteLine("GetProductionBatches Mapperly Execution Time: " + stopwatchMapperly.ElapsedMilliseconds + " ms");

            // Log counts for comparison
            _logger.LogInformation("AutoMapped: {Count} | MapsterMapped: {Count} ",
                autoMappedProductionBatches.Count(), mapsterMappedProductionBatches.Count());
            var productionBatchList = new ProductionBatchList();
            productionBatchList.ProductionBatches.AddRange(autoMappedProductionBatches);

            return productionBatchList;
        }

        public override async Task<CustomerList> GetCustomers(Empty request, ServerCallContext context)
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();

            List<CustomerMapper> customerMappedList = new List<CustomerMapper>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string query = "EXEC GetCustomers";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        customerMappedList.Add(new CustomerMapper
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1)
                        });
                    }
                }
            }

            long beforeMemoryAutoMapper = GC.GetTotalMemory(true);
            Stopwatch stopwatchAutoMapper = new Stopwatch();
            stopwatchAutoMapper.Start();

            var autoMappedCustomers = _mapper.Map<IEnumerable<Customer>>(customerMappedList);

            long afterMemoryAutoMapper = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetCustomers AutoMapper: {(afterMemoryAutoMapper - beforeMemoryAutoMapper)} Bytes");

            stopwatchAutoMapper.Stop();
            Console.WriteLine("GetCustomers AutoMapper Execution Time: " + stopwatchAutoMapper.ElapsedMilliseconds + " ms");

            long beforeMemoryMapster = GC.GetTotalMemory(true);

            Stopwatch stopwatchMapster = new Stopwatch();
            stopwatchMapster.Start();

            var mapsterMappedCustomers = customerMappedList.Adapt<IEnumerable<Customer>>(_mapsterConfig);

            long afterMemoryMapster = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetCustomers Mapster: {(afterMemoryMapster - beforeMemoryMapster)} Bytes");

            stopwatchMapster.Stop();
            Console.WriteLine("GetCustomers Mapster Execution Time: " + stopwatchMapster.ElapsedMilliseconds + " ms");

            long beforeMemoryMapperly = GC.GetTotalMemory(true);

            Stopwatch stopwatchMapperly = new Stopwatch();
            stopwatchMapperly.Start();

            var mapperlyMappedCustomers = _myMapper.MapCustomers(customerMappedList);

            long afterMemoryMapperly = GC.GetTotalMemory(true);
            Console.WriteLine($"Memory Used by GetCustomers Mapperly: {(afterMemoryMapperly - beforeMemoryMapperly)} Bytes");

            stopwatchMapperly.Stop();
            Console.WriteLine("GetCustomers Mapperly Execution Time: " + stopwatchMapperly.ElapsedMilliseconds + " ms");

            _logger.LogInformation("AutoMapped: {Count} | MapsterMapped: {Count} | MapperlyMapped: {Count}",
                autoMappedCustomers.Count(), mapsterMappedCustomers.Count(), mapperlyMappedCustomers.Count());

            var customers = new CustomerList();
            customers.Customers.AddRange(autoMappedCustomers);
            return customers;
        }

        public override async Task<InsertCustomerResponse> InsertCustomer(InsertCustomerRequest request, ServerCallContext context)
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            try
            {
                var customerMapper = new CustomerMapper { Name = request.Name };

                long beforeMemoryAutoMapper = GC.GetTotalMemory(true);

                Stopwatch stopwatchAutoMapper = new Stopwatch();
                stopwatchAutoMapper.Start();

                var autoMappedCustomer = _mapper.Map<Customer>(customerMapper);
                Console.WriteLine($"AutoMapper Mapped -> ID: {autoMappedCustomer.Id}, Name: {autoMappedCustomer.Name}");

                long afterMemoryAutoMapper = GC.GetTotalMemory(true);
                Console.WriteLine($"Memory Used by InsertCustomer AutoMapper: {(afterMemoryAutoMapper - beforeMemoryAutoMapper)} Bytes");

                stopwatchAutoMapper.Stop();
                Console.WriteLine("InsertCustomer AutoMapper Execution Time: " + stopwatchAutoMapper.Elapsed.TotalMicroseconds + " micro seconds");

                long beforeMemoryMapster = GC.GetTotalMemory(true);
                Stopwatch stopwatchMapster = new Stopwatch();
                stopwatchMapster.Start();

                var mapsterMappedCustomer = customerMapper.Adapt<Customer>();
                Console.WriteLine($"Mapster Mapped -> ID: {mapsterMappedCustomer.Id}, Name: {mapsterMappedCustomer.Name}");

                long afterMemoryMapster = GC.GetTotalMemory(true);
                Console.WriteLine($"Memory Used by InsertCustomer Mapster: {(afterMemoryMapster - beforeMemoryMapster)} Bytes");

                stopwatchMapster.Stop();
                Console.WriteLine("InsertCustomer Mapster Execution Time: " + stopwatchMapster.Elapsed.TotalMicroseconds + " micro seconds");


                long beforeMemoryMapperly = GC.GetTotalMemory(true);
                Stopwatch stopwatchMapperly = new Stopwatch();
                stopwatchMapperly.Start();

                var mapperlyMappedCustomer = _myMapper.MapCustomers(new List<CustomerMapper> { customerMapper }).FirstOrDefault();
                Console.WriteLine($"Mapperly Mapped -> ID: {mapperlyMappedCustomer.Id}, Name: {mapperlyMappedCustomer.Name}");

                long afterMemoryMapperly = GC.GetTotalMemory(true);
                Console.WriteLine($"Memory Used by InsertCustomer Mapperly: {(afterMemoryMapperly - beforeMemoryMapperly)} Bytes");

                stopwatchMapperly.Stop();
                Console.WriteLine("InsertCustomer Mapperly Execution Time: " + stopwatchMapperly.Elapsed.TotalMicroseconds + " micro seconds");

                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    await conn.OpenAsync();
                    string query = "INSERT INTO Customer (Name) VALUES (@Name)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", request.Name);
                        int rowsAffected = await cmd.ExecuteNonQueryAsync();

                        if (rowsAffected > 0)
                        {
                            return new InsertCustomerResponse
                            {
                                Success = true,
                                Message = "Customer inserted successfully"
                            };
                        }
                    }
                }
                return new InsertCustomerResponse
                {
                    Success = false,
                    Message = "Failed to insert customer"
                };
            }
            catch (Exception ex)
            {
                return new InsertCustomerResponse
                {
                    Success = false,
                    Message = $"Error: {ex.Message}"
                };
            }
        }
    }
}