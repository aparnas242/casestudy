using AutoMapper;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using MapperCaseStudy;
using MapperCaseStudygRPC.Models;
using Microsoft.Data.SqlClient;
using Mapster;
using System;
using System.Threading.Tasks;
using static MapperCaseStudy.MapperService;
using MapperCaseStudygRPC;

namespace MapperCaseStudy.Services
{
    public class MapperService : MapperServiceBase
    {
        private readonly ILogger<MapperService> _logger;
        private readonly IMapper _mapper;
        private readonly TypeAdapterConfig _mapsterConfig;
        private readonly IMyMapper _myMapper;

        private readonly string _connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=PharmaDB;Integrated Security=True;";

        public MapperService(ILogger<MapperService> logger, IMapper mapper, IMyMapper myMapper)
        {
            _logger = logger;
            _mapper = mapper;
            _mapsterConfig = new TypeAdapterConfig();
            _myMapper = myMapper;
        }

        
        public override async Task<CustomerList> GetCustomers(Empty request, ServerCallContext context)
        {
            List<CustomerMapper> customerMappedList = new List<CustomerMapper>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string query = "EXEC GetCustomers";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        customerMappedList.Add(new CustomerMapper
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1)
                        });
                    }
                }
            }
            var autoMappedCustomers = _mapper.Map<IEnumerable<Customer>>(customerMappedList);
            var mapsterMappedCustomers = customerMappedList.Adapt<IEnumerable<Customer>>(_mapsterConfig);
            var mapperlyMappedCustomers = _myMapper.MapCustomers(customerMappedList);

            // Log the results for comparison
            _logger.LogInformation("AutoMapped: {Count} | MapsterMapped: {Count} | MapperlyMapped: {Count}",
                autoMappedCustomers.Count(), mapsterMappedCustomers.Count(), mapperlyMappedCustomers.Count());

            var customers = new CustomerList();
            customers.Customers.AddRange(autoMappedCustomers);
            return customers;
        }
        public override async Task<PharmacyDetailsList> GetPharmacyDetails(Empty request, ServerCallContext context)
        {
            var pharmacyDetailsMappedList = new List<PharmacyDetailsMapper>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {

                await conn.OpenAsync();
                string query = "EXEC GetPharmacyDetails";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        pharmacyDetailsMappedList.Add(new PharmacyDetailsMapper
                        {
                            PharmacyId = reader.GetInt32(0),
                            PharmacyName = reader.GetString(1),
                            PharmacyLocation = reader.GetString(2),
                            TotalMedicineBatches = reader.GetInt32(3),
                            TotalPrescriptionsIssued = reader.GetInt32(4),
                            SupplierNames = reader.GetString(5)
                        });
                    }
                }
            }
            var autoMappedPharmacyDetails = _mapper.Map<IEnumerable<PharmacyDetails>>(pharmacyDetailsMappedList);
            var mapsterMappedPharmacyDetails = pharmacyDetailsMappedList.Adapt<IEnumerable<PharmacyDetails>>(_mapsterConfig);
            var mapperlyMappedPharmacyDetails = _myMapper.MapPharmacyDetails(pharmacyDetailsMappedList);

            // Log the results for comparison
            _logger.LogInformation("AutoMapped: {Count} | MapsterMapped: {Count} | MapperlyMapped: {Count}",
                autoMappedPharmacyDetails.Count(), mapsterMappedPharmacyDetails.Count(), mapperlyMappedPharmacyDetails.Count());

            var pharmacyDetailsList = new PharmacyDetailsList();
            pharmacyDetailsList.PharmacyDetails.AddRange(autoMappedPharmacyDetails);

            return pharmacyDetailsList;
        }

        public override async Task<MedicinePrescriptionInfo> GetMedicinePrescriptionInfo(MedicinePrescriptionRequest request, ServerCallContext context)
        {
            var medPrescriptionList = new MedPrescriptionMapper();

            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    using (var command = new SqlCommand("GetMedicinePrescriptionInfo", connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@PatientId", request.PatientId);

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {

                                medPrescriptionList.CustomerId = reader.GetInt32(0); 
                                medPrescriptionList.PatientName = reader.GetString(1); 
                                medPrescriptionList.PrescriptionId = reader.GetInt32(2); 
                                medPrescriptionList.PrescriptionDate = reader.GetDateTime(3); 
                                medPrescriptionList.MedicineId = reader.GetInt32(4); 
                                medPrescriptionList.MedicineName = reader.GetString(5); 
                                medPrescriptionList.SupplierName = reader.GetString(6); 
                                medPrescriptionList.SupplierCountry = reader.GetString(7);
                             
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                throw new RpcException(new Status(StatusCode.Internal, "An error occurred while fetching prescription data."));
            }

            var autoMappedResponse = _mapper.Map<MedicinePrescriptionInfo>(medPrescriptionList);
            var mapsterMappedResponse = medPrescriptionList.Adapt<MedicinePrescriptionInfo>(_mapsterConfig);
            var mapperlyMappedResponse = _myMapper.MapMedicinePrescription(medPrescriptionList);

            // Log the mappings for comparison
            _logger.LogInformation("AutoMapped: {Name} | MapsterMapped: {Name} | MapperlyMapped: {Name}",
                autoMappedResponse.PatientName, mapsterMappedResponse.PatientName, mapperlyMappedResponse.PatientName);

            return autoMappedResponse;
        }

        public override async Task<ProductionBatchList> GetProductionBatches(Empty request, ServerCallContext context)
        {
            var batchProductVendorMappedList = new List<BatchProductVendorMapper>();

            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                string query = "EXEC GetProductionBatchesWithProductsAndVendors"; 

                using (var cmd = new SqlCommand(query, connection))
                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        batchProductVendorMappedList.Add(new BatchProductVendorMapper
                        {
                            BatchId = reader.GetInt32(0),
                            BatchNumber = reader.GetString(1),
                            ExpiryDate = reader.GetDateTime(2),
                            Quantity = reader.GetInt32(3),
                            ProductId = reader.GetInt32(4),
                            ProductName = reader.GetString(5),
                            VendorId = reader.GetInt32(6),
                            VendorName = reader.GetString(7),
                            VendorCountry = reader.GetString(8)
                         });
                    }
                }
            }

            // AutoMapper mapping
            var autoMappedProductionBatches = _mapper.Map<IEnumerable<ProductionBatch>>(batchProductVendorMappedList);

            // Mapster mapping
            var mapsterMappedProductionBatches = batchProductVendorMappedList.Adapt<IEnumerable<ProductionBatch>>();

            // Mapperly mapping
            var mapperlyMappedProductionBatches = _myMapper.MapBatchProductVendors(batchProductVendorMappedList);

            // Log counts for comparison
            _logger.LogInformation("AutoMapped: {Count} | MapsterMapped: {Count} ",
                autoMappedProductionBatches.Count(), mapsterMappedProductionBatches.Count());
            var productionBatchList = new ProductionBatchList();
            productionBatchList.ProductionBatches.AddRange(autoMappedProductionBatches);

            return productionBatchList;
        }
    }
}

