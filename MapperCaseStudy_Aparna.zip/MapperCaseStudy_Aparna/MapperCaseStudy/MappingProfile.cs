﻿using AutoMapper;
using Google.Protobuf.WellKnownTypes;
using MapperCaseStudy;
using MapperCaseStudygRPC.Models;

namespace MapperCaseStudygRPC
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<CustomerMapper, Customer>().ReverseMap();

            CreateMap<MedPrescriptionMapper, MedicinePrescriptionInfo>()
                .ForMember(dest => dest.CustomerId, opt => opt.MapFrom(src => src.CustomerId))
                .ForMember(dest => dest.PatientName, opt => opt.MapFrom(src => src.PatientName))
                .ForMember(dest => dest.PrescriptionId, opt => opt.MapFrom(src => src.PrescriptionId))
                .ForMember(dest => dest.PrescriptionDate, opt => opt.MapFrom(src => Timestamp.FromDateTime(src.PrescriptionDate.ToUniversalTime())))
                .ForMember(dest => dest.MedicineId, opt => opt.MapFrom(src => src.MedicineId))
                .ForMember(dest => dest.MedicineName, opt => opt.MapFrom(src => src.MedicineName))
                .ForMember(dest => dest.SupplierName, opt => opt.MapFrom(src => src.SupplierName))
                .ForMember(dest => dest.SupplierCountry, opt => opt.MapFrom(src => src.SupplierCountry));

            CreateMap<PharmacyDetailsMapper, PharmacyDetails>();

            CreateMap<BatchProductVendorMapper, ProductionBatch>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.BatchId))
                .ForMember(dest => dest.BatchNumber, opt => opt.MapFrom(src => src.BatchNumber))
                .ForMember(dest => dest.ExpiryDate, opt => opt.MapFrom(src => Timestamp.FromDateTime(src.ExpiryDate.ToUniversalTime())))
                .ForMember(dest => dest.Quantity, opt => opt.MapFrom(src => src.Quantity))
                .ForMember(dest => dest.Products, opt => opt.MapFrom(src => new List<Product>
                {
                    new Product
                    {
                        Id = src.ProductId,
                        Name = src.ProductName,
                        Vendor = new Vendor
                        {
                            Id = src.VendorId,
                            Name = src.VendorName,
                            Country = src.VendorCountry
                        }
                    }
                }));


        }
    }
}
