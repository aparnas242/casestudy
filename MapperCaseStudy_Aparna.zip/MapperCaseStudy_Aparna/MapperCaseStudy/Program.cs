using MapperCaseStudy.Services;
using Microsoft.Extensions.DependencyInjection;
using AutoMapper;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Hosting;
using MapperCaseStudygRPC;
using MapperCaseStudygRPC.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddGrpc();

//Automapper

builder.Services.AddAutoMapper(typeof(MappingProfile));
MapsterMappingConfig.ConfigureMappings();
builder.Services.AddSingleton<MappingProfile>();
builder.Services.AddSingleton<IMyMapper, MyMapper>();

var services = new ServiceCollection();


var app = builder.Build();

// Configure the HTTP request pipeline.
app.MapGrpcService<MapperService>();
app.MapGet("/", () => "gRPC Pharmacy Service is running.");
app.Run();
