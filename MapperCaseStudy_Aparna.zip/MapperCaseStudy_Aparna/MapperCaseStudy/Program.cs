using MapperCaseStudy.Services;
using Microsoft.Extensions.DependencyInjection;
using AutoMapper;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Hosting;
using MapperCaseStudygRPC;
using MapperCaseStudygRPC.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
//builder.Services.AddGrpc();
builder.Services.AddGrpc(options =>
{
    options.MaxReceiveMessageSize = 50 * 1024 * 1024;
    options.MaxSendMessageSize = 50 * 1024 * 1024;
});


//Automapper

builder.Services.AddAutoMapper(typeof(MappingProfile));
MapsterMappingConfig.ConfigureMappings();
//builder.Services.AddSingleton<MappingProfile>();
builder.Services.AddScoped< MappingProfile>();
builder.Services.AddSingleton<IMyMapper, MyMapper>();

var services = new ServiceCollection();


var app = builder.Build();

app.MapGrpcService<MapperService>();
app.MapGet("/", () => "gRPC Pharmacy Service is running.");
app.Run();
