﻿using MapperCaseStudy;
using MapperCaseStudygRPC.Models;
using Riok.Mapperly.Abstractions;
using System.Collections.Generic;

namespace MapperCaseStudygRPC
{
    [Mapper]
    public partial class MyMapper : IMyMapper
    {
        public partial IEnumerable<Customer> MapCustomers(IEnumerable<CustomerMapper> customers);
        public partial MedicinePrescriptionInfo MapMedicinePrescription(MedPrescriptionMapper prescription);
        public partial IEnumerable<PharmacyDetails> MapPharmacyDetails(IEnumerable<PharmacyDetailsMapper> pharmacyDetails);
        public partial IEnumerable<ProductionBatch> MapBatchProductVendors(IEnumerable<BatchProductVendorMapper> batchProductVendors);

        public partial IEnumerable<CustomerMapper> MapCustomersBack(IEnumerable<Customer> customers);
        public partial Customer MapCustomer(CustomerMapper customer);
    }
}
