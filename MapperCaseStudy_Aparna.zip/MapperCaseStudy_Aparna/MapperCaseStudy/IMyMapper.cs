﻿using MapperCaseStudy;
using MapperCaseStudygRPC.Models;
using Riok.Mapperly.Abstractions;

namespace MapperCaseStudygRPC
{
    public interface IMyMapper
    {
        IEnumerable<Customer> MapCustomers(IEnumerable<CustomerMapper> customers);
        MedicinePrescriptionInfo MapMedicinePrescription(MedPrescriptionMapper prescription);
        IEnumerable<PharmacyDetails> MapPharmacyDetails(IEnumerable<PharmacyDetailsMapper> pharmacyDetails);
        IEnumerable<ProductionBatch> MapBatchProductVendors(IEnumerable<BatchProductVendorMapper> batchProductVendors);
        IEnumerable<CustomerMapper> MapCustomersBack(IEnumerable<Customer> customers);
    }
}
