﻿using Google.Protobuf.WellKnownTypes;
using MapperCaseStudy;
using MapperCaseStudygRPC.Models;
using Mapster;

namespace MapperCaseStudygRPC
{
    public class MapsterMappingConfig
    {
        public static void ConfigureMappings()
        {
            TypeAdapterConfig<CustomerMapper, Customer>.NewConfig();

            TypeAdapterConfig<PharmacyDetailsMapper, PharmacyDetails>.NewConfig();

            TypeAdapterConfig<MedPrescriptionMapper, MedicinePrescriptionInfo>.NewConfig()
                .Map(dest => dest.CustomerId, src => src.CustomerId)
                .Map(dest => dest.PatientName, src => src.PatientName)
                .Map(dest => dest.PrescriptionId, src => src.PrescriptionId)
                .Map(dest => dest.PrescriptionDate, src => Google.Protobuf.WellKnownTypes.Timestamp.FromDateTime(src.PrescriptionDate.ToUniversalTime()))
                .Map(dest => dest.MedicineId, src => src.MedicineId)
                .Map(dest => dest.MedicineName, src => src.MedicineName)
                .Map(dest => dest.SupplierName, src => src.SupplierName)
                .Map(dest => dest.SupplierCountry, src => src.SupplierCountry);

            TypeAdapterConfig<BatchProductVendorMapper, ProductionBatch>.NewConfig()
                .Map(dest => dest.Id, src => src.BatchId)
                .Map(dest => dest.BatchNumber, src => src.BatchNumber)
                .Map(dest => dest.ExpiryDate, src => Timestamp.FromDateTime(src.ExpiryDate.ToUniversalTime()))
                .Map(dest => dest.Quantity, src => src.Quantity)
                .Map(dest => dest.Products, src => src.Adapt<Product>());  

            TypeAdapterConfig<BatchProductVendorMapper, Product>.NewConfig()
                .Map(dest => dest.Id, src => src.ProductId)
                .Map(dest => dest.Name, src => src.ProductName)
                .Map(dest => dest.Vendor, src => src.Adapt<Vendor>());

            TypeAdapterConfig<BatchProductVendorMapper, Vendor>.NewConfig()
                .Map(dest => dest.Id, src => src.VendorId)
                .Map(dest => dest.Name, src => src.VendorName)
                .Map(dest => dest.Country, src => src.VendorCountry);
        }
    }
}
