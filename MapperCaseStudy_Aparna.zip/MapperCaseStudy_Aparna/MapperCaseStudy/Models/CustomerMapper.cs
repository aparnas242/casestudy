﻿namespace MapperCaseStudygRPC.Models
{
    public class CustomerMapper
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
