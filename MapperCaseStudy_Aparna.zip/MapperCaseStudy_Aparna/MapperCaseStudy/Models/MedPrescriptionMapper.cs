﻿namespace MapperCaseStudygRPC.Models
{
    public class MedPrescriptionMapper
    {
        public int CustomerId { get; set; }  // c.Id
        public string PatientName { get; set; }  // c.Name
        public int PrescriptionId { get; set; }  // p.Id
        public DateTime PrescriptionDate { get; set; }  // p.DateIssued (DateTime, not DateOnly)
        public int MedicineId { get; set; }  // m.Id
        public string MedicineName { get; set; }  // m.Name
        public string SupplierName { get; set; }  // s.Name
        public string SupplierCountry { get; set; }  // s.Country
    }
}
