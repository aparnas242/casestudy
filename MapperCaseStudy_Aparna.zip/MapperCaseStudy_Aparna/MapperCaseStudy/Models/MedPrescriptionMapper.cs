﻿namespace MapperCaseStudygRPC.Models
{
    public class MedPrescriptionMapper
    {
        public int CustomerId { get; set; } 
        public string PatientName { get; set; } 
        public int PrescriptionId { get; set; }  
        public DateTime PrescriptionDate { get; set; }  
        public int MedicineId { get; set; } 
        public string MedicineName { get; set; }  
        public string SupplierName { get; set; }  
        public string SupplierCountry { get; set; }  
    }
}
