﻿namespace MapperCaseStudygRPC.Models
{
    public class BatchProductVendorMapper
    {
        public int BatchId { get; set; }  
        public string BatchNumber { get; set; }  
        public DateTime ExpiryDate { get; set; }  
        public int Quantity { get; set; }  
        public int ProductId { get; set; }  
        public string ProductName { get; set; }  
        public int VendorId { get; set; }  
        public string VendorName { get; set; }  
        public string VendorCountry { get; set; }  
    }
}
