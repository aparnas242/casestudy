﻿namespace MapperCaseStudygRPC.Models
{
    public class BatchProductVendorMapper
    {
        public int BatchId { get; set; }  // b.Id
        public string BatchNumber { get; set; }  // b.BatchNumber
        public DateTime ExpiryDate { get; set; }  // b.ExpiryDate
        public int Quantity { get; set; }  // b.Quantity
        public int ProductId { get; set; }  // m.Id
        public string ProductName { get; set; }  // m.Name
        public int VendorId { get; set; }  // s.Id
        public string VendorName { get; set; }  // s.Name
        public string VendorCountry { get; set; }  // s.Country
    }
}
