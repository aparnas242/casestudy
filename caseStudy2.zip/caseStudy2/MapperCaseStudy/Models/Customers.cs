﻿namespace MapperCaseStudygRPC.Models
{
    public class Customers
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
