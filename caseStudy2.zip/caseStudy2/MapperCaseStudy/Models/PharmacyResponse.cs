﻿namespace MapperCaseStudygRPC.Models
{
    public class PharmacyResponse
    {
        public List<PharmacyDetails> PharmacyDetails { get; set; }
    }
}
