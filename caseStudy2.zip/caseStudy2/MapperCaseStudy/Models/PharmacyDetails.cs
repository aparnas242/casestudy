﻿namespace MapperCaseStudygRPC.Models
{
    public class PharmacyDetails
    {
        public int PharmacyId { get; set; }
        public string PharmacyName { get; set; }
        public string PharmacyLocation { get; set; }
        public int TotalMedicineBatches { get; set; }
        public int TotalPrescriptionsIssued { get; set; }
        public string SupplierNames { get; set; }
    }
}
