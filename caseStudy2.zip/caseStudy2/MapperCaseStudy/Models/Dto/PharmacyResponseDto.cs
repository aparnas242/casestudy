﻿namespace MapperCaseStudygRPC.Models.Dto
{
    public class PharmacyResponseDto
    {
        public List<PharmacyDetailsDto> PharmacyDetails { get; set; }
    }
}
