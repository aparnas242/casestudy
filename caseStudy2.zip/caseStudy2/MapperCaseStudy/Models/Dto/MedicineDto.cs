﻿namespace MapperCaseStudygRPC.Models.Dto
{
    public class MedicineDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int SupplierId { get; set; }
    }
}
