using MapperCaseStudy.Services;
using Microsoft.Extensions.DependencyInjection;
using AutoMapper;
using Microsoft.AspNetCore.Builder;
//using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using MapperCaseStudygRPC;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddGrpc();

//builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());


var services = new ServiceCollection();


var app = builder.Build();

// Configure the HTTP request pipeline.
app.MapGrpcService<MapperService>();
app.MapGet("/", () => "gRPC Pharmacy Service is running.");
app.Run();
