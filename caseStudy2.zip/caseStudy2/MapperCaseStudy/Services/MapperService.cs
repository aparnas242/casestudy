using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using MapperCaseStudy;
using Microsoft.Data.SqlClient;
using System;
using System.Threading.Tasks;
using static MapperCaseStudy.MapperService;

namespace MapperCaseStudy.Services
{
    public class MapperService : MapperServiceBase
    {
        private readonly ILogger<MapperService> _logger;
        private readonly string _connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=PharmaDB;Integrated Security=True;";

        public MapperService(ILogger<MapperService> logger)
        {
            _logger = logger;
        }

        public override async Task<PharmacyList> GetPharmacies(Empty request, ServerCallContext context)
        {
            var pharmacies = new PharmacyList();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string query = "EXEC GetPharmacies";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        pharmacies.Pharmacies.Add(new Pharmacy
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            Location = reader.GetString(2)
                        });
                    }
                }
            }
            return pharmacies;
        }

        public override async Task<PharmacyDetailsList> GetPharmacyDetails(Empty request, ServerCallContext context)
        {
            var pharmacyDetailsList = new PharmacyDetailsList();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string query = "EXEC GetPharmacyDetails";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        pharmacyDetailsList.PharmacyDetails.Add(new PharmacyDetails
                        {
                            PharmacyId = reader.GetInt32(0),
                            PharmacyName = reader.GetString(1),
                            PharmacyLocation = reader.GetString(2),
                            TotalMedicineBatches = reader.GetInt32(3),
                            TotalPrescriptionsIssued = reader.GetInt32(4),
                            SupplierNames = reader.GetString(5)
                        });
                    }
                }
            }
            return pharmacyDetailsList;
        }

        public override async Task<CustomerList> GetCustomers(Empty request, ServerCallContext context)
        {
            var customers = new CustomerList();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string query = "EXEC GetCustomers";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        customers.Customers.Add(new Customer
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1)
                        });
                    }
                }
            }
            return customers;
        }

        public override async Task<DoctorList> GetDoctors(Empty request, ServerCallContext context)
        {
            var doctors = new DoctorList();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string query = "EXEC GetDoctors";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        doctors.Doctors.Add(new Doctor
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            Specialization = reader.GetString(2)
                        });
                    }
                }
            }
            return doctors;
        }

        public override async Task<MedicineList> GetMedicines(Empty request, ServerCallContext context)
        {
            var medicines = new MedicineList();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string query = "EXEC GetMedicines";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        medicines.Medicines.Add(new Medicine
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            SupplierId = reader.GetInt32(2)
                        });
                    }
                }
            }
            return medicines;
        }

        public override async Task<SupplierList> GetSuppliers(Empty request, ServerCallContext context)
        {
            var suppliers = new SupplierList();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string query = "EXEC GetSuppliers";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        suppliers.Suppliers.Add(new Supplier
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            Country = reader.GetString(2)
                        });
                    }
                }
            }
            return suppliers;
        }

        public override async Task<BatchList> GetBatches(Empty request, ServerCallContext context)
        {
            var batchList = new BatchList();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string query = "EXEC GetBatches"; // Ensure stored procedure returns all columns

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        batchList.Batches.Add(new Batch
                        {
                            Id = reader.GetInt32(0),  
                            MedicineId = reader.GetInt32(1), 
                            BatchNumber = reader.GetString(2),
                            ExpiryDate = Timestamp.FromDateTime(reader.GetDateTime(3).ToUniversalTime()),
                            Quantity = reader.GetInt32(4),
                            FormattedExpiryDate = reader.GetDateTime(3).ToString("yyyy-MM-dd")
                        });
                    }
                }
            }
            return batchList;
        }

    }
}
