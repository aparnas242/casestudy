﻿using AutoMapper;
using MapperCaseStudy;
using MapperCaseStudygRPC.Models;
using Supplier = MapperCaseStudygRPC.Models.Supplier;
//using Models;


namespace MapperCaseStudygRPC
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            //CreateMap<Supplier, SupplierList>()
              //  .ForMember(dest => dest.name, opt => opt.MapFrom(src => src.Name));
        }
    }
}
