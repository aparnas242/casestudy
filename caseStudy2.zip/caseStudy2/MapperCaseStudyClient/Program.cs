﻿//using Google.Protobuf.WellKnownTypes;
using AutoMapper;
using Grpc.Net.Client;
using MapperCaseStudy;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        var channel = GrpcChannel.ForAddress("https://localhost:7290");
        var client = new MapperService.MapperServiceClient(channel);

        await GetPharmacies(client);
        await GetCustomers(client);
        await GetDoctors(client);
        await GetMedicines(client);
        await GetSuppliers(client);
        await GetPharmacyDetails(client);
        await GetBatches(client); // Add this line to call GetBatches
    }

    static async Task GetPharmacies(MapperService.MapperServiceClient client)
    {
        var response = await client.GetPharmaciesAsync(new Empty());
        Console.WriteLine("\nPharmacies:");
        foreach (var pharmacy in response.Pharmacies)
        {
            Console.WriteLine($"ID: {pharmacy.Id}, Name: {pharmacy.Name}, Location: {pharmacy.Location}");
        }
    }

    static async Task GetCustomers(MapperService.MapperServiceClient client)
    {
        var response = await client.GetCustomersAsync(new Empty());
        Console.WriteLine("\nCustomers:");
        foreach (var customer in response.Customers)
        {
            Console.WriteLine($"ID: {customer.Id}, Name: {customer.Name}");
        }
    }

    static async Task GetDoctors(MapperService.MapperServiceClient client)
    {
        var response = await client.GetDoctorsAsync(new Empty());
        Console.WriteLine("\nDoctors:");
        foreach (var doctor in response.Doctors)
        {
            Console.WriteLine($"ID: {doctor.Id}, Name: {doctor.Name}, Specialization: {doctor.Specialization}");
        }
    }

    static async Task GetMedicines(MapperService.MapperServiceClient client)
    {
        var response = await client.GetMedicinesAsync(new Empty());
        Console.WriteLine("\nMedicines:");
        foreach (var medicine in response.Medicines)
        {
            Console.WriteLine($"ID: {medicine.Id}, Name: {medicine.Name}, Supplier ID: {medicine.SupplierId}");
        }
    }

    static async Task GetSuppliers(MapperService.MapperServiceClient client)
    {
        var response = await client.GetSuppliersAsync(new Empty());
        Console.WriteLine("\nSuppliers:");
        foreach (var supplier in response.Suppliers)
        {
            Console.WriteLine($"ID: {supplier.Id}, Name: {supplier.Name}, Country: {supplier.Country}");
        }
    }

    static async Task GetPharmacyDetails(MapperService.MapperServiceClient client)
    {
        var response = await client.GetPharmacyDetailsAsync(new Empty());
        Console.WriteLine("\nPharmacy Details:");
        foreach (var details in response.PharmacyDetails)
        {
            Console.WriteLine($"Pharmacy ID: {details.PharmacyId}, Name: {details.PharmacyName}, Location: {details.PharmacyLocation}, " +
                              $"Total Medicine Batches: {details.TotalMedicineBatches}, Prescriptions Issued: {details.TotalPrescriptionsIssued}, " +
                              $"Suppliers: {details.SupplierNames}");
        }
    }

    // New method to get batches
    static async Task GetBatches(MapperService.MapperServiceClient client)
    {
        var response = await client.GetBatchesAsync(new Empty());
        Console.WriteLine("\nBatches:");
        foreach (var batch in response.Batches)
        {
            var expiryDate = batch.ExpiryDate.ToDateTime();
            Console.WriteLine($"Batch Number: {batch.BatchNumber}, Expiry Date: {expiryDate:yyyy-MM-dd}, Quantity: {batch.Quantity}");
        }
    }

    //static async Task GetBatches(MapperService.MapperServiceClient client, IMapper mapper)
    //{
    //    var response = await client.GetBatchesAsync(new Empty());
    //    var batchDtos = mapper.Map<List<BatchDto>>(response.Batches);

    //    Console.WriteLine("\nBatches:");
    //    foreach (var batchDto in batchDtos)
    //    {
    //        Console.WriteLine($"Batch Number: {batchDto.BatchNumber}, Expiry Date: {batchDto.ExpiryDate}, Quantity: {batchDto.Quantity}");
    //    }
    //}
}
//static async Task Main()
//{
//    var channel = GrpcChannel.ForAddress("https://localhost:7290");
//    var client = new MapperService.MapperServiceClient(channel);

//    var services = new ServiceCollection();
//    services.AddAutoMapper(typeof(Program));
//    var serviceProvider = services.BuildServiceProvider();
//    var mapper = serviceProvider.GetRequiredService<IMapper>();

//    await GetPharmacies(client);
//    await GetCustomers(client);
//    await GetDoctors(client);
//    await GetMedicines(client);
//    await GetSuppliers(client);
//    await GetPharmacyDetails(client);
//    await GetBatches(client, mapper); // Pass the mapper instance
//}